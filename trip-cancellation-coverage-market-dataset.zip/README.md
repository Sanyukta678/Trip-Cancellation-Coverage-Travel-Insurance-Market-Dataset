# Trip Cancellation Coverage Travel Insurance Market Dataset
Structured dataset generated from publicly available information on the NextMSC report page.

Files Included:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- toc.txt

License: MIT
